import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/shared/employee.service';
//import {EmployeeService } from '../employee.service'
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
declare var M: any;
import { EmployeeC } from 'src/app/shared/employee.modelFi'

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers: [EmployeeService]
})

export class EmployeeComponent implements OnInit {


  constructor(private service: EmployeeService,
    private toastr: ToastrService) { }
    list3:EmployeeC[];

  ngOnInit() {
    this.resetForm();
    //this.service.refreshList2();
    this.refreshList2();
  }
  //this.service.refreshList();
    refreshList2(){
    this.service.refreshList3().subscribe((data3)=>{
      this.list3=JSON.parse(JSON.stringify(data3))
    })
  }

  resetForm(form?: NgForm) {
    if(form)
    //if (form != null)     //if new data is there
    //if(form)
      // form.resetForm();
      form.reset();
    this.service.formData2 = {
      //this.
      _id: '',
      userName: '',
      email: '',
      phone: '',
      gender: '',
      age: null
    }
  }
  
  onSubmit(form: NgForm) {
    this.service.postEmployee(form.value).subscribe((res) => {
      console.log(form.value)
      this.toastr.success('Inserted successfully', 'EMP2. Register');
      this.resetForm(form);
      this.service.refreshList3();
      //sthis.refreshList2();
      //M.toast({ html: 'Saved successfully', classes: 'rounded' });
    });
  }
  addEmp(){
    this.service.postEmployee2(this.service.formData2);
  }

   // onDelete(_id: string, form: NgForm) {
    onDelete(_id: string) {
      if (confirm('Are you sure to delete this record?')) {
        this.service.deleteEmployee(_id).subscribe((res) => {
          this.service.refreshList();
          this.refreshList2();
          //form.reset();
          this.toastr.warning('Deleted successfully', 'EMP1. Register');
          //M.toast({ html: 'Deleted successfully', classes: 'rounded' });
        });
      }
    }
  
}
