// const express =require('express');
// const ProductData=require('./src/model/Productdata');
// const cors=require("cors");  //cross origin resource sharing 
// var bodyparser=require('body-parser');
// var app=new express;
// const port=3000;
// app.use(cors());  //resource sharing will  occure,consolidating two port
// app.use(bodyparser.json())

// //var app=new express;//const app=new express();
// var router=require("./src/routesFo/routerFi");
// app.use('/',router);
// //app.use(cors({ origin: 'http://localhost:4200' }));




//     app.listen(3000,function(){
//         console.log("listening to portt:"+port);
//     })

const express =require('express');
const EmployeeData=require('./src/model/employeedata');
const cors=require("cors");
var bodyparser=require('body-parser');
var app=new express;
const port=3001;
app.use(cors());
app.use(bodyparser.json())

var router=require("./src/routesFo/routerFi");
app.use('/',router);

app.listen(3001,function(){
    console.log('listening to portt:'+port);
})