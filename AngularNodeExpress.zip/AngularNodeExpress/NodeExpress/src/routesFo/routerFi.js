// const express =require('express');
// const ProductData=require('../model/Productdata');
// var router=express.Router();
// var ObjectId = require('mongoose').Types.ObjectId;


// router.get('/products',function(req,res){
//     res.header("access-Control-Allow-Origin","*")
//     res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS')
//     ProductData.find()
//     .then(function(products){
//         res.send(products);
//     })
// })
    
//     router.post('/insert',function(req,res){               //to add one more record
//         res.header("Access-Control-Allow-Origin","*")
//         res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS')
//         console.log(req.body);
//         var product3={
//             productId:req.body.product2.productId,
//             productName:req.body.product2.productName,
//             productCode:req.body.product2.productCode,
//             releaseDate:req.body.product2.releaseDate,
//             description:req.body.product2.description,
//             price:req.body.product2.price,
//             starRating:req.body.product2.starRating,
//             imageUrl:req.body.product2.imageUrl
//         }
//         var product4=new ProductData(product3);
//         product4.save();
//     });

//     // router.post('/products', (req, res) => {                 //
//     //     var emp1 = new ProductData({
//     //         productId: req.body. productId,
//     //         productName: req.body.productName,
//     //         productCode: req.body.productCode,
//     //         releaseDate: req.body.releaseDate,
//     //         description: req.body.description,
//     //         price: req.body.price,
//     //         starRating: req.body.starRating,
//     //         imageUrl: req.body.imageUrl
//     //     });
//     //     emp1.save((err, doc) => {
//     //         if (!err) { res.send(doc); }
//     //         else { console.log('Error in Employee Save :' + JSON.stringify(err, undefined, 2)); }
//     //     });
//     // });
    
//     router.put('/products/:id', (req, res) => {          //edit
//         if (!ObjectId.isValid(req.params.id))
//             return res.status(400).send(`No record with given id : ${req.params.id}`);
    
//         var emp3 = {
//             productId: req.body. productId,
//             productName: req.body.productName,
//             productCode: req.body.productCode,
//             releaseDate: req.body.releaseDate,
//             description: req.body.description,
//             price: req.body.price,
//             starRating: req.body.starRating,
//             imageUrl: req.body.imageUrl
//         };
//         ProductData.findByIdAndUpdate(req.params.id, { $set: emp3 }, { new: true }, (err, doc) => {
//             if (!err) { res.send(doc); }
//             else { console.log('Error in Employee Update :' + JSON.stringify(err, undefined, 2)); }
//         });
//     });

    // router.delete('/Delete/:id', (req, res) => {  //delete
    //     if (!ObjectId.isValid(req.params.id))
    //         return res.status(400).send(`No record with given id : ${req.params.id}`);
    
    //     ProductData.findByIdAndRemove(req.params.id, (err, doc) => {
    //         if (!err) { res.send(doc); }
    //         else { console.log('Error in Employee Delete :' + JSON.stringify(err, undefined, 2)); }
    //     });
    // });

    
//     module.exports=router;

    const express=require('express');
const EmployeeData=require('../model/employeedata');
var router=express.Router();
var ObjectId=require('mongoose').Types.ObjectId;

router.get('/employees',function(req,res){
    // res.header("access-Control-Allow-Origin","*")
    // res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS')
    EmployeeData.find()
    .then(function(employees){
        res.send(employees)
    })
})

router.post('/employees',function(req,res){
    res.header("Access-Control-Allow-Origin","*")
    res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS')
    console.log(req.body);
    var employee3={
        userName:req.body.employee2.userName,
        email:req.body.employee2.email,
        phone:req.body.employee2.phone,
        gender:req.body.employee2.gender,
        age:req.body.employee2.age
    }
    var employee4=new EmployeeData(employee3);
    employee4.save();
})

router.delete('/employees/:id', (req, res) => {  //delete
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    EmployeeData.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Employee Delete :' + JSON.stringify(err, undefined, 2)); }
    });
});

module.exports=router;
